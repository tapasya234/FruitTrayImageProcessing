/*
Author: Tapasya Gutta
File: Part2
Description: This is the 1st part of the Assignment 1 of Video Analytics
In this part, Two images need to be converted from RGB format to HSV formart

Reference: http://www.rapidtables.com/convert/color/rgb-to-hsv.htm
Reference: http://docs.opencv.org/2.4/modules/imgproc/doc/miscellaneous_transformations.html
*/

#include<opencv2/core/core.hpp>
#include<opencv2\highgui\highgui.hpp>
#include<opencv2\imgproc\imgproc.hpp>

#include<iostream>
#include<conio.h>
#include<algorithm>

using namespace std;
using namespace cv;

cv::Mat swapColors(cv::Mat imgRGB) {

	cv::Mat swappedImg = Mat::zeros(imgRGB.size(), imgRGB.type());
	cv::Mat imgHSV = Mat::zeros(imgRGB.size(), imgRGB.type());

	int lowerRed1 = 0;
	int lowerRed2 = 155;
	int upperRed1 = 15;
	int upperRed2 = 179;
	int lowerGreen = 30 ;
	int middleGreen = 60;
	int upperGreen = 90;

	cv::cvtColor(imgRGB, imgHSV, CV_BGR2HSV);

	for (int y = 0; y < imgHSV.rows; y++) {
		for (int x = 0; x < imgHSV.cols; x++) {
			Vec3b pixel = imgHSV.at<Vec3b>(y, x);
			
			int hue = pixel.val[0];
			int sHue = hue;

			if (hue >= lowerRed1 && hue <= upperRed1)
				sHue += 55;
			else if (hue >= lowerRed2 && hue <= upperRed2)
				sHue -= 110;
			else if (hue >= lowerGreen && hue <= middleGreen)
				sHue += 157;
			else if (hue >= middleGreen && hue <= upperGreen)
				sHue -= 53;
			else
				sHue = hue;

			
			sHue = sHue % 180;
			pixel.val[0] = sHue;
			swappedImg.at<Vec3b>(y, x) = pixel;
		}
	}

	cv::cvtColor(swappedImg, swappedImg, CV_HSV2BGR);
	return swappedImg;
}

int main() {

	cv::Mat imgRGB1;
	imgRGB1 = cv::imread("image.jpg");
	cv::Mat imgRGB2;
	imgRGB2 = cv::imread("image1.jpg");
	

	if (imgRGB1.empty() || imgRGB2.empty()) {          // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return(0);                                              // and exit program
	}

	cv::Mat swappedImg1 = Mat::zeros(imgRGB1.size(), imgRGB1.type());
	cv::Mat swappedImg2 = Mat::zeros(imgRGB2.size(), imgRGB2.type());

	swappedImg1 = swapColors(imgRGB1);
	swappedImg2 = swapColors(imgRGB2);

	// creating windows
	cv::namedWindow("RGB_Image_1", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("RGB_Image_2", CV_WINDOW_AUTOSIZE);
	
	cv::namedWindow("Swapped_Image_1", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Swapped_Image_2", CV_WINDOW_AUTOSIZE);
	
	// showing windows
	cv::imshow("RGB_Image_1", imgRGB1);     
	cv::imshow("RGB_Image_2", imgRGB2);
	
	cv::imshow("Swapped_Image_1", swappedImg1);
	cv::imshow("Swapped_Image_2", swappedImg2);
	

	// Saving the new image
	imwrite("swappedImage1.jpg", swappedImg1);
	imwrite("swappedImage2.jpg", swappedImg2);
	

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);


}