/*
Author: Tapasya Gutta
File: Part2
Description: This is the 1st part of the Assignment 1 of Video Analytics
In this part, Two images need to be converted from RGB format to HSV formart

Reference: http://www.rapidtables.com/convert/color/rgb-to-hsv.htm
Reference: http://docs.opencv.org/2.4/modules/imgproc/doc/miscellaneous_transformations.html
*/

#include<opencv2/core/core.hpp>
#include<opencv2\highgui\highgui.hpp>
#include<opencv2\imgproc\imgproc.hpp>

#include<iostream>
#include<conio.h>
#include<algorithm>

using namespace std;
using namespace cv;

cv::Mat rgbToHsv(cv::Mat imgRGB) {

	cv::Mat imgHSV = Mat::zeros(imgRGB.size(), imgRGB.type());

	for (int y = 0; y < imgRGB.rows; y++) {
		for (int x = 0; x < imgRGB.cols; x++) {
			Vec3b pixel = imgRGB.at<Vec3b>(y, x);
			uchar b = pixel.val[0];
			uchar g = pixel.val[1];
			uchar r = pixel.val[2];

			// scaling to fit the 0 to 1 range
			float blue = b / 255.0f;
			float green = g / 255.0f;
			float red = r / 255.0f;

			float max = std::fmax(std::fmax(red, green), blue);
			float min = std::fmin(std::fmin(red, green), blue);
			float delta = max - min;

			// calculation of value(V)
			float value = max;

			// calculation of saturation(S)
			float saturation;
			if (max == 0)
				saturation = 0;
			else
				saturation = delta / max;

			// calculation of hue(H)
			float hue;
			if (delta == 0) {
				hue = 0;
			}
			else if (max == red) {
				hue = 60 * ((green - blue)) / delta;
			}
			else if (max == green) {
				hue = 120 + ((60 * (blue - red)) / delta);
			}
			else
				hue = 240 + ((60 * (red - green)) / delta); 

				
			pixel.val[2] = (int)(hue / 2);
			pixel.val[1] = (int)(saturation * 255);
			pixel.val[0] = (int)(value * 255); 

			imgHSV.at<cv::Vec3b>(y, x) = pixel;
		}
	}
	return imgHSV;
} 

int main() {

	cv::Mat imgRGB1; 
	imgRGB1 = cv::imread("image.jpg");
	cv::Mat imgRGB2;
	imgRGB2 = cv::imread("image1.jpg");

	if(imgRGB1.empty() || imgRGB2.empty()) {          // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return(0);                                              // and exit program
	}

	cv::Mat imgHSV1 = Mat::zeros(imgRGB1.size(), imgRGB1.type());
	cv::Mat imgHSV2 = Mat::zeros(imgRGB2.size(), imgRGB2.type());

	imgHSV1 = rgbToHsv(imgRGB1);
	imgHSV2 = rgbToHsv(imgRGB2);

	// creating windows
	cv::namedWindow("RGB_Image_1", CV_WINDOW_AUTOSIZE);     // note: you can use CV_WINDOW_NORMAL which allows resizing the window
	cv::namedWindow("RGB_Image_2", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("HSV_Image_1", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("HSV_Image_2", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
															 // CV_WINDOW_AUTOSIZE is the default
	cv::imshow("RGB_Image_1", imgRGB1);     // show windows
	cv::imshow("RGB_Image_2", imgRGB2);
	cv::imshow("HSV_Image_1", imgHSV1);
	cv::imshow("HSV_Image_2", imgHSV2);

	// Saving the new image
	imwrite("hsvImage1.jpg", imgHSV1);
	imwrite("hsvImage2.jpg", imgHSV2);

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);


}