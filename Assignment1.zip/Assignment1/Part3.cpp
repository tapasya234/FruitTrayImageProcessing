/*
Author: Tapasya Gutta
File: Part2
Description: This is the 1st part of the Assignment 1 of Video Analytics
In this part, Two images need to be converted from RGB format to HSV formart

Reference: http://www.rapidtables.com/convert/color/rgb-to-hsv.htm
Reference: http://docs.opencv.org/2.4/modules/imgproc/doc/miscellaneous_transformations.html
*/

#include<opencv2\highgui\highgui.hpp>
#include<opencv2\imgproc\imgproc.hpp>

#include<iostream>
#include<conio.h>
#include<algorithm>

using namespace std;
using namespace cv;

cv::Mat detectRedAppleHSV(cv::Mat img) {

	cv::Mat detectedImg = Mat::zeros(img.size(), img.type());
	int lowerRed1 = 0;
	int lowerRed2 = 155;
	int upperRed1 = 15;
	int upperRed2 = 179;
	
	for (int y = 0; y < img.rows; y++) {
		for (int x = 0; x < img.cols; x++) {
			Vec3b pixel = img.at<Vec3b>(y, x);

			int hue = pixel.val[0];
			int sHue = hue;

			if (hue >= lowerRed1 && hue <= upperRed1)
				sHue = 179;
			else if (hue >= lowerRed2 && hue <= upperRed2)
				sHue = 179;
			else
				sHue = 0;


			//sHue = sHue % 180;
			pixel.val[0] = sHue;
			detectedImg.at<Vec3b>(y, x) = pixel;
		}
	}
	return detectedImg;
}

cv::Mat detectRedAppleRGB(cv::Mat img) {

	cv::Mat detectedImg = Mat::zeros(img.size(), img.type());

	return detectedImg;
}

int main() {

	cv::Mat imgRGB1;
	imgRGB1 = cv::imread("image.jpg");
	cv::Mat imgRGB2;
	imgRGB2 = cv::imread("image1.jpg");
	cv::Mat imgHSV3;
	imgRGB1 = cv::imread("hsvImage1.jpg");
	cv::Mat imgHSV4;
	imgRGB2 = cv::imread("hsvImage2.jpg");

	if (imgRGB1.empty() /*|| imgRGB2.empty() || imgHSV3.empty() || imgHSV4.empty()*/) {          // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return(0);                                              // and exit program
	}

	cv::Mat detectedImg1 = Mat::zeros(imgRGB1.size(), imgRGB1.type());
	cv::Mat detectedImg2 = Mat::zeros(imgRGB2.size(), imgRGB2.type());
	cv::Mat detectedImg3 = Mat::zeros(imgHSV3.size(), imgHSV3.type());
	cv::Mat detectedImg4 = Mat::zeros(imgHSV4.size(), imgHSV4.type());

	detectedImg1 = detectRedAppleRGB(imgRGB1);
	detectedImg2 = detectRedAppleRGB(imgRGB2); 
	detectedImg3 = detectRedAppleHSV(imgHSV3);
	detectedImg4 = detectRedAppleHSV(imgHSV4);

	// creating windows
	cv::namedWindow("RGB_Image_1", CV_WINDOW_AUTOSIZE);     
	cv::namedWindow("RGB_Image_2", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("HSV_Image_3", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("HSV_Image_4", CV_WINDOW_AUTOSIZE); 
	cv::namedWindow("Detected_Image_1", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Detected_Image_2", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Detected_Image_3", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Detected_Image_4", CV_WINDOW_AUTOSIZE);


	cv::imshow("RGB_Image_1", imgRGB1);     // show windows
	cv::imshow("RGB_Image_2", imgRGB2);
	cv::imshow("HSV_Image_3", imgHSV3);
	cv::imshow("HSV_Image_4", imgHSV4);
	cv::imshow("Detected_Image_1", detectedImg1);
	cv::imshow("Detected_Image_2", detectedImg2);
	cv::imshow("Detected_Image_3", detectedImg3);
	cv::imshow("Detected_Image_4", detectedImg4);

	// Saving the new image
	imwrite("detectedImage1.jpg", detectedImg1);
	imwrite("detectedImage2.jpg", detectedImg2);
	imwrite("detectedImage3.jpg", detectedImg3);
	imwrite("detectedImage4.jpg", detectedImg4);

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);


}