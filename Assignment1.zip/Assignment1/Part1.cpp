/*
	Author: Tapasya Gutta
	File: Part1
	Description: This is the 1st part of the Assignment 1 of Video Analytics
	In this part, a new image needs to be created using the old image 
	by adjusting the original image by adding a constant factor of 50

	g(x) = alpha * f(x) + beta
	where, f(x) is the original image
		   g(x) is the final image
		   alpha is the gain parameter, also controls contrast
		   beta is the bias parameter, also controls brightness
	Reference: http://www.docs.opencv.org/2.4/doc/tutorials/core/basic_linear_transform/basic_linear_transform.html
*/

#include<iostream>
#include<conio.h>

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

double alpha = 1.0; 
double beta = 50;

int main() {
	cv::Mat imgOriginal;        // input image
	imgOriginal = cv::imread("image.jpg");          // open image
	
	if (imgOriginal.empty()) {                                  // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return(0);                                              // and exit program
	}

	cv::Mat imgNew = Mat::zeros(imgOriginal.size(), imgOriginal.type());

	// Performing the operation g(x) = alpha * f(x) + beta
	for (int y = 0; y < imgOriginal.rows; y++) {
		for (int x = 0; x < imgOriginal.cols; x++) {
			for (int c = 0; c < 3; c++) {
				imgNew.at<Vec3b>(y, x)[c] = saturate_cast<uchar>(alpha * (imgOriginal.at<Vec3b>(y, x)[c]) + beta);
			}
		}
	}

	
	// creating windows
	cv::namedWindow("Original Image", CV_WINDOW_AUTOSIZE);     // note: you can use CV_WINDOW_NORMAL which allows resizing the window
	cv::namedWindow("New Image", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
															// CV_WINDOW_AUTOSIZE is the default
	cv::imshow("Original Image", imgOriginal);     // show windows
	cv::imshow("New Image", imgNew);

	// Saving the new image
	imwrite("image1.jpg", imgNew);

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);
}
